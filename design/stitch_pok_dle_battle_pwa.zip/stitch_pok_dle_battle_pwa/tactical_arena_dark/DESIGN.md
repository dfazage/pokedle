---
name: Tactical Arena Dark
colors:
  surface: '#131317'
  surface-dim: '#131317'
  surface-bright: '#39393d'
  surface-container-lowest: '#0e0e12'
  surface-container-low: '#1b1b1f'
  surface-container: '#1f1f23'
  surface-container-high: '#2a292e'
  surface-container-highest: '#353439'
  on-surface: '#e4e1e7'
  on-surface-variant: '#c0c7d2'
  inverse-surface: '#e4e1e7'
  inverse-on-surface: '#303034'
  outline: '#8a919c'
  outline-variant: '#404750'
  surface-tint: '#9bcbff'
  primary: '#9bcbff'
  on-primary: '#003256'
  primary-container: '#5ba8f0'
  on-primary-container: '#003c64'
  inverse-primary: '#00629f'
  secondary: '#ffb3ae'
  on-secondary: '#65080e'
  secondary-container: '#882424'
  on-secondary-container: '#ff9e98'
  tertiary: '#72d9bb'
  on-tertiary: '#00382c'
  tertiary-container: '#4bb498'
  on-tertiary-container: '#004134'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d0e4ff'
  primary-fixed-dim: '#9bcbff'
  on-primary-fixed: '#001d34'
  on-primary-fixed-variant: '#004a79'
  secondary-fixed: '#ffdad7'
  secondary-fixed-dim: '#ffb3ae'
  on-secondary-fixed: '#410004'
  on-secondary-fixed-variant: '#852222'
  tertiary-fixed: '#8ff6d6'
  tertiary-fixed-dim: '#72d9bb'
  on-tertiary-fixed: '#002018'
  on-tertiary-fixed-variant: '#005140'
  background: '#131317'
  on-background: '#e4e1e7'
  surface-variant: '#353439'
  electric-yellow: '#f7c948'
  spectral-violet: '#8b6cd9'
  surface-glass: rgba(22, 22, 34, 0.65)
  surface-elevated: '#161622'
  rim-light: rgba(255, 255, 255, 0.12)
typography:
  headline-xl:
    fontFamily: Outfit
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 42px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Outfit
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Outfit
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Outfit
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Outfit
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 22px
  body-md:
    fontFamily: Outfit
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Outfit
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Outfit
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Outfit
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Outfit
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 0.75rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.875rem
  space-lg: 1.25rem
  space-xl: 1.75rem
---

## Brand & Style

This design system drives a fast-paced, glassmorphic daily monster battle and guessing experience calibrated for high-contrast mobile play. The aesthetic merges tactical esports telemetries with luminous frosted glass surfaces and saturated elemental signatures.

### Personality & Atmosphere
- **Persona:** Ultra-modern, competitive, snappy, and atmospheric. It channels late-night arena duels where statistical clarity meets radiant game VFX.
- **Target Audience:** Digital natives, monster-battler tacticians, and daily puzzle enthusiasts who demand responsive, tactile interactions within a 390px mobile viewport.
- **Design Philosophy:** Frosted dark-mode glassmorphism overlaid on an abyss-grade void (`#0B0B0F`). Translucent backdrops, fine 1px light-catching specular rims, and neon halos delineate interactive surfaces from stage environments.

## Colors

The color architecture is built around deep spatial blackness infused with hyper-chromatic elemental energies:

### Core Roles
- **Primary (`#5BA8F0` - Electric Cyan):** Dedicated to player telemetries, primary actionable triggers, confirmed correct guesses, and radiant focal points.
- **Secondary (`#F0716B` - Flame Coral):** Represents rival actions, physical damage states, critical health warnings, and urgent countdowns.
- **Tertiary (`#6FD6B8` - Mint Life):** Signifies full vitality pools, victory resolutions, positive stat differentials, and confirmed affinities.
- **Neutral (`#0B0B0F` - Deep Abyss):** Ground canvas creating an unlit backdrop against which frosted glass layers and neon diffusions resonate.

### Tactical Accents
- **Electric Yellow (`#F7C948`):** Denotes critical effectiveness, daily battle streaks, and mid-tier resource bars.
- **Spectral Violet (`#8B6CD9`):** Designates mystery slots, obscure typings, and ultimate readiness meters.
- **Glass Surfaces:** Translucent tokens (`rgba(22, 22, 34, 0.65)`) layered over blur fields allow ambient battlefield backdrops to filter through controls.

## Typography

Outfit supplies geometric precision with friendly curvature, echoing both clean game HUDs and collectible toy typography.

### Usage Standards
- **Numerical Primacy:** HP bars, damage floating tags, battle countdowns, and turn tallies must always use `fontWeight: 800` to mirror arcade combat readouts.
- **Multilingual Density:** Accommodate longer localized copy (e.g., French attack names and stats) using `label-md` and `label-sm` with upper tracking (`0.04em`–`0.06em`) to guarantee legibility on dense HUD shelves.
- **Uppercase Hierarchy:** Action commands, elemental tags, and battle status badges are rendered in uppercase using label tokens.

## Layout & Spacing

Layout rhythm is tailored strictly around the thumb-reach zone of standard mobile screens (390×844) while remaining centered and framed on larger viewports.

### Grid & Ergonomics
- **Grid Layout:** 2-column or 4-column configurations using a `0.75rem` (`12px`) gutter (`gutter`) to arrange move sets, guess matrices, and element wheels.
- **Section Margin:** Outer frames adhere to `1rem` (`16px`) edge padding (`margin`), safeguarding interface bounds from device bezels.
- **Vertical Ratio:** The operational screen is divided into two distinct zones:
  - **Upper 52% (Stage):** Preserved for combatants, elemental visual effects, and environmental arena perspective.
  - **Lower 48% (Command Pad):** Packed with glass controls, moves, guess history, and interactive pills positioned for quick one-handed tapping.
- **System Offsets:** Top headers maintain a `48px` safe ceiling to avoid device sensor notches; critical action rows float `34px` above the bottom edge to bypass home swipe bars.

## Elevation & Depth

Visual hierarchy uses frosted glass panels, selective backdrops, and luminous chromatic blooms over flat drop shadows.

### Glassmorphic Surfaces
- **Frosted Panels:** Floating containers, battle logs, and stat trays use `background: rgba(22, 22, 34, 0.65)` combined with `backdrop-filter: blur(16px)` and `-webkit-backdrop-filter: blur(16px)`.
- **Specular Rim Lights:** Every glass surface carries a top and side highlight border: `1px solid rgba(255, 255, 255, 0.12)`, accentuating physical glass edges in dark space.

### Radiant Neon Halos
- **Active Player Focus:** Primary elements, selected attack cards, and player HP casts radiate an ambient cyan aura: `box-shadow: 0 0 16px rgba(91, 168, 240, 0.45)`.
- **Hostile & Critical Focus:** Opponent trays and critical danger cues emit a flame coral glow: `box-shadow: 0 0 16px rgba(240, 113, 107, 0.45)`.
- **Modal Backdrops:** Under-sheet overlays employ high darkness with minimal blur (`background: rgba(11, 11, 15, 0.75)`, `backdrop-filter: blur(8px)`) to focus attention on elevated drawers.

## Shapes

The geometric framework pairs rounded panels with fluid pill capsules, creating a cohesive, handheld tactile finish.

### Geometry Rules
- **Tactical Panels & Attack Cards:** Default cards and tactical pads implement a 16px radius (`rounded-lg`) to balance perimeter softness with tight screen economy.
- **Interactive Capsules:** Filter chips, elemental type capsules, and action buttons utilize pure pill geometry (`border-radius: 9999px`).
- **Arena Bottom Sheets:** Slide-up modal drawers implement an exaggerated 24px–28px curve on top corners (`border-top-left-radius: 1.5rem`, `border-top-right-radius: 1.5rem`) with a flat base.

## Components

### Buttons
- **Primary Command:** Pill-shaped (`border-radius: 9999px`) button filled with `#5BA8F0` or `#F0716B`. Features `16px` vertical padding, uppercase `label-lg` typography, and an elemental glow matching the fill. On press, scales to `0.97` with enhanced bloom brightness.
- **Glass / Ghost Action:** Frosted pill with `background: rgba(255, 255, 255, 0.06)`, `backdrop-filter: blur(8px)`, and a `1px solid rgba(255, 255, 255, 0.16)` border. Hover or active state increases fill to `rgba(255, 255, 255, 0.12)`.

### Chips & Pill Badges
- **Elemental Badges:** 26px tall pills containing an elemental icon and type name in `label-sm`. Built with translucent dark cores (`rgba(22, 22, 34, 0.8)`), saturated elemental text, and a `1px` border matching the type color at `40%` opacity.
- **Filter Chips:** Frosted badges that transition from muted neutral outlines to saturated glowing fills upon activation.

### HP & Gauge Meters
- **Tactical HP Rails:** Segmented bars composed of discrete rounded pips (8 to 10 increments) against an unlit track background (`#1A1A22`):
  - **Healthy (>50% PV):** `#6FD6B8` segments with an ambient mint glow.
  - **Warning (20%–50% PV):** `#F7C948` segments with an amber glow.
  - **Critical (<20% PV):** `#F0716B` segments pulsing with a 1.2s flame bloom animation.

### Input Fields
- **Search & Guess Matrix:** 16px rounded glass input shell (`background: rgba(22, 22, 34, 0.75)`, `border: 1px solid rgba(255, 255, 255, 0.14)`). Contains an inset glass magnifying glass, vibrant white typing text (`#FFFFFF`), and muted placeholder text (`#8A919C`). Focus state triggers a 2px `#5BA8F0` border and an inner specular sheen.

### Cards & Attack Tiles
- **Tactical Move Pads:** 2×2 grid cards designed for thumb actuation. Frosted surface housing move name (`label-lg`), power/PP gauges, and elemental corner icon. Active state invokes a solid 2px primary neon border and an inward gradient flash.

### Checkboxes & Segmented Selectors
- **Toggles & Selectors:** Custom 20px frosted circles and rounded segment strips. Unchecked state presents a dark glass core with a faint border; checked state fills with vibrant `#5BA8F0` containing a crisp white tick or indicator dot.

### Bottom Sheets (Feuilles Inférieures)
- **Drawers:** Full-width bottom modals boasting a 24px top radius, top grab pill (`36px × 4px` at `rgba(255, 255, 255, 0.2)`), and frosted background showing blurred combat stages behind stats and move disclosures.