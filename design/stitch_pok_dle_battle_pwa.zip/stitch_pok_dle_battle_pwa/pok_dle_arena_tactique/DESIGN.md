---
name: Pokédle Arena Tactique
colors:
  surface: '#131317'
  surface-dim: '#131317'
  surface-bright: '#39393d'
  surface-container-lowest: '#0e0e12'
  surface-container-low: '#1b1b1f'
  surface-container: '#1f1f23'
  surface-container-high: '#2a292e'
  surface-container-highest: '#353439'
  on-surface: '#e4e1e7'
  on-surface-variant: '#c0c7d2'
  inverse-surface: '#e4e1e7'
  inverse-on-surface: '#303034'
  outline: '#8a919c'
  outline-variant: '#404750'
  surface-tint: '#9bcbff'
  primary: '#9bcbff'
  on-primary: '#003256'
  primary-container: '#5ba8f0'
  on-primary-container: '#003c64'
  inverse-primary: '#00629f'
  secondary: '#ffb3ae'
  on-secondary: '#65080e'
  secondary-container: '#882424'
  on-secondary-container: '#ff9e98'
  tertiary: '#72d9bb'
  on-tertiary: '#00382c'
  tertiary-container: '#4bb498'
  on-tertiary-container: '#004134'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d0e4ff'
  primary-fixed-dim: '#9bcbff'
  on-primary-fixed: '#001d34'
  on-primary-fixed-variant: '#004a79'
  secondary-fixed: '#ffdad7'
  secondary-fixed-dim: '#ffb3ae'
  on-secondary-fixed: '#410004'
  on-secondary-fixed-variant: '#852222'
  tertiary-fixed: '#8ff6d6'
  tertiary-fixed-dim: '#72d9bb'
  on-tertiary-fixed: '#002018'
  on-tertiary-fixed-variant: '#005140'
  background: '#131317'
  on-background: '#e4e1e7'
  surface-variant: '#353439'
typography:
  display-hero:
    fontFamily: Outfit
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 42px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Outfit
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Outfit
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Outfit
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Outfit
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 22px
  body-md:
    fontFamily: Outfit
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Outfit
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Outfit
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Outfit
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Outfit
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 0.75rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.875rem
  space-lg: 1.25rem
  space-xl: 1.75rem
---

## Brand & Style

This design system establishes a high-energy, tactical daily battle experience tailored for mobile web (PWA viewport 390x844). The aesthetic fuses playful pastel card collecting with electrifying competitive arena combat. 

### Identity & Tone
- **Audience:** French-speaking Gen Z and millennial fans of daily puzzle games (Wordle/Pokedle style) and Pokémon battle enthusiasts seeking fast, tactile mobile confrontations.
- **Personality:** Competitive, playful, ultra-modern, and snappy. The tone balances lighthearted collection interfaces with high-stakes esports energy during battle resolution.
- **Visual Synthesis:** A dual-paradigm language. Out-of-battle phases (roster curation, guess logging, stats) embrace soft pastel cards, subtle Pokéball geometry, and clean pill badges. The active battleground transitions into a neon-charged dark mode arena with segmented energy displays and luminous strikes.

## Colors

The palette manages two explicit environment states while maintaining cohesive semantic accents:

### Core Battle Tones
- **Primary (`#5BA8F0` - Bleu Cyan / Vitesse):** Drives player-side UI, active tactical selections, water/flying visual traits, and radiant primary button actions.
- **Secondary (`#F0716B` - Corail Flamme):** Designates adversary indicators, critical physical strikes, fire/fighting affinities, and urgent countdown states.
- **Tertiary (`#6FD6B8` - Menthe Plante):** Represents full health conditions, winning guesses, confirmed types, and positive outcome notifications.
- **Neutral (`#0B0B0F` - Abysse Nocturne):** The canvas base for battlegrounds and dark mode sheets, providing deep contrast for glowing elemental VFX.

### Ambient & Type Tones
- **Soleil Jaune (`#F7C948`):** Electric/super-effective indicators, streak achievements, and battle ratings.
- **Violet Spectre (`#8B6CD9`):** Psychic/ghost indicators, mystery reveal card states, and special gauge charges.
- **Pastel Neutral Ground (`#F6F8FC`):** Base canvas during light exploration views and pokedex menus.
- **Surface Elevation Dark (`#161622`):** Card backing in dark mode arena sheets.

## Typography

Outfit provides structural roundness that mirrors friendly character art while delivering geometric sharpness in high-tension matchups.

### Typography Rules
- **French Nomenclature Priority:** French words require slightly more horizontal room (e.g., "Points de Vie" instead of "HP", "Attaque Spéciale" instead of "Sp. Atk"). Keep labels compact with `label-md` and `label-sm` to prevent awkward line breaks in narrow mobile cards.
- **Number Weighting:** All statistical damage readouts, HP quantities, and daily timer counters utilize `fontWeight: 800` to mirror arcade combat counters.

## Layout & Spacing

This system prioritizes a handheld thumb-zone architecture calibrated strictly to 390x844 viewports.

### Grid & Composition
- **Canvas Shell:** 390px fixed fluid boundary centered on larger desktop viewports with a 16px lateral margin (`margin`).
- **Gutter Distribution:** 12px columns (`gutter`) facilitating clean 2-column move pads and 3-column daily guess tables.
- **Safe Area Insets:** Top header clears 48px to accommodate device status notches; interactive action buttons clear 34px bottom margins for system gestures.
- **Height-Locked Arena:** The battle screen allocates 52% vertical real estate to the battleground stage, 48% to the attack grid and action controls.

## Elevation & Depth

Visual hierarchy leverages dual-mode layering: tinted atmospheric diffusion for light exploration screens, and crisp neon glassmorphism for battle phases.

### Light State Depth
- **Soft Type Glows:** Cards cast color-coordinated ambient drop shadows matching the Pokémon's primary type: `0 10px 24px -4px rgba(type-color, 0.28)`.
- **Pokéball Watermark:** Vector silhouettes of oversized Pokéball contours sit at 4% opacity (`rgba(0, 0, 0, 0.04)`) across background panels to break large flat surfaces without interfering with legibility.
- **Bottom Drawers:** Elevated modal sheets feature a 28px top border radius with a gentle directional shadow: `0 -12px 32px rgba(11, 11, 15, 0.08)`.

### Dark Battle Arena Depth
- **Glassmorphism Panels:** Action pads and opponent stat trays use `background: rgba(22, 22, 34, 0.65)` layered over a `backdrop-filter: blur(16px)` with an interior highlight border: `1px solid rgba(255, 255, 255, 0.12)`.
- **Neon HP Core Elevation:** Health bars and action triggers project a vivid laser bloom: `0 0 16px rgba(91, 168, 240, 0.5)` for player cyan, and `0 0 16px rgba(240, 113, 107, 0.5)` for rival orange.

## Shapes

A balanced curvature system establishes a soft yet energetic visual rhythm across compact screens.

### Shape Language
- **Panels and Attack Tiles:** Base cards and tactical tiles use a 16px radius (`rounded-lg`), creating an approachable hand-held feel without wasting interior canvas.
- **Type Badges & CTAs:** Badges, filter chips, and primary triggers use pill shapes (`border-radius: 9999px`) to match collectible capsules.
- **Modal Sheets:** Slide-up bottom sheets employ a distinctive 28px top curve (`border-top-left-radius: 28px`, `border-top-right-radius: 28px`) for a plush presentation.

## Components

### Boutons d'Action (Buttons)
- **Primary Strike Action:** High-saturation cyan (`#5BA8F0`) or coral (`#F0716B`) fill with 16px vertical padding, bold centered text (`label-lg`), and an ambient glow. Pressed states scale to `0.97` with an intensified bloom.
- **Secondary Ghost Action:** Transparent surface with a `1.5px` border tinted by elemental accents (`rgba(255, 255, 255, 0.2)` in dark mode, `rgba(11, 11, 15, 0.15)` in light mode).

### Badges de Type (Pill Badges)
- Pill-shaped capsules (height: 26px) showcasing Pokémon elements (Feu, Eau, Plante, Électrik). In light mode, they utilize pastel fills with 90% saturated matching text. In dark mode, they switch to semi-transparent backgrounds with vivid saturated text and glowing 1px borders.

### Jauges d'Énergie & PV (HP Segmented Bars)
- Segmented tactical health meters divided into discrete rounded blocks (8 to 10 pips).
- **Green Tier (>50% PV):** `#6FD6B8` with mint halo.
- **Yellow Tier (20–50% PV):** `#F7C948` with sunshine halo.
- **Critical Tier (<20% PV):** `#F0716B` with a flashing flame bloom animation.

### Cartes d'Attaque (Attack Cards)
- 2x2 grid tiles sized for single-thumb activation. Each tile houses a 3D sprite or render, move name in `label-lg`, and power/accuracy indicators. Selected state triggers a 2px neon border and an inward glass sheen.

### Champ de Recherche Pokédle (Input Fields)
- Rounded 16px search input with inset icon, predictive autocomplete dropdown, and soft background (`#FFFFFF` in light mode, `#1A1A26` in dark arena mode). Displays French placeholder text: *"Devinez le Pokémon du jour..."*

### Feuilles Inférieures (Bottom-Sheets)
- Drawers featuring a 28px top radius and an integrated pill-shaped grab handle (36px x 4px). Surfaces house move sets, evolutionary charts, and end-of-round post-match analytics.